<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];
$config = require 'config.php';

try {
    $dsn = 'mysql:host=' . $config['database']['host'] . ';dbname=' . $config['database']['database'] . ';port=' . $config['database']['port'];
    $pdo = new PDO($dsn, $config['database']['username'], $config['database']['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "فشل الاتصال بقاعدة البيانات: " . $e->getMessage();
    die();
}

// جلب الطلبات المفتوحة
$stmt = $pdo->query("SELECT * FROM contact_requests WHERE status = 'open'");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب المستخدمين لتحويل المهام
$stmt_users = $pdo->query("SELECT id, email FROM users");
$users = $stmt_users->fetchAll(PDO::FETCH_ASSOC);

// تحويل الطلب إلى مهمة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
    $request_id = $_POST['request_id'];
    $assigned_to = $_POST['assigned_to'];

    // تحويل الطلب إلى مهمة
    $stmt = $pdo->prepare("INSERT INTO tasks (contact_request_id, assigned_to) VALUES (:contact_request_id, :assigned_to)");
    $stmt->bindParam(':contact_request_id', $request_id);
    $stmt->bindParam(':assigned_to', $assigned_to);
    $stmt->execute();

    // تحديث حالة الطلب إلى 'closed'
    $stmt = $pdo->prepare("UPDATE contact_requests SET status = 'closed' WHERE id = :id");
    $stmt->bindParam(':id', $request_id);
    $stmt->execute();

    // إضافة حركة جديدة في سجل الحركات
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (:user_id, 'Task Assigned', :details)");
    $stmt->bindParam(':user_id', $_SESSION['user']['id']);
    $stmt->bindParam(':details', "Task assigned to user ID $assigned_to for request ID $request_id");
    $stmt->execute();

    header('Location: dashboard.php');
    exit;
}
?>

    <div class="container">
        <h2>طلبات التواصل</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>رقم الجوال</th>
                    <th>الخدمة</th>
                    <th>الوصف</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?php echo $request['name']; ?></td>
                    <td><?php echo $request['email']; ?></td>
                    <td><?php echo $request['phone']; ?></td>
                    <td><?php echo $request['service']; ?></td>
                    <td><?php echo $request['description']; ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                            <select name="assigned_to" required>
                                <option value="">اختر مستخدم</option>
                                <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"><?php echo $user['email']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="assign_task" class="btn btn-success">تحويل لمهمة</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

