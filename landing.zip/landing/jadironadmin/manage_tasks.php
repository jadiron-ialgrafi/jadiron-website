<?php
require 'config.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$user_id = $_SESSION['user']['id'];
$user_role = $_SESSION['user']['role'];

// جلب جميع المهام بناءً على الصلاحيات
if ($user_role == 'admin') {
    // الأدمن يرى جميع المهام
    $stmt = $pdo->query("SELECT * FROM tasks");
} elseif ($user_role == 'manager') {
    // المدير يرى المهام المرتبطة بفريقه فقط
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE assigned_to IN (SELECT id FROM users WHERE manager_id = :manager_id)");
    $stmt->execute([':manager_id' => $user_id]);
} else {
    // المستخدم يرى المهام المسندة إليه فقط
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE assigned_to = :user_id");
    $stmt->execute([':user_id' => $user_id]);
}

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دالة لحساب الوقت منذ بدء المهمة
function calculateElapsedTime($start_date) {
    $now = new DateTime();
    $start = new DateTime($start_date);
    $interval = $now->diff($start);
    return $interval->format('%a يوم و %h ساعة');
}

// دالة لجلب اسم المستخدم بناءً على ID
function getUserNameById($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT name FROM users WHERE id = :id");
    $stmt->execute([':id' => $user_id]);
    return $stmt->fetchColumn();
}

// دالة لتسجيل العمليات
function log_activity($pdo, $user_id, $action, $details) {
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (:user_id, :action, :details, NOW())");
    $stmt->execute([
        ':user_id' => $user_id,
        ':action' => $action,
        ':details' => $details
    ]);
}

// معالجة إغلاق المهمة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['close_task'])) {
    $task_id = $_POST['task_id'];
    
    // تحديث الحالة إلى "مغلقة"
    $stmt = $pdo->prepare("UPDATE tasks SET status = 'مغلقة' WHERE id = :task_id");
    $stmt->execute([':task_id' => $task_id]);

    // تسجيل الحركة
    log_activity($pdo, $user_id, 'إغلاق مهمة', "تم إغلاق المهمة $task_id.");

    $_SESSION['success_message'] = "تم إغلاق المهمة بنجاح.";
    header("Location: manage_tasks.php");
    exit;
}

// معالجة تحويل المهمة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transfer_task'])) {
    $task_id = $_POST['task_id'];
    $new_user_id = $_POST['assigned_to'];
    
    // تحويل المهمة للمستخدم الجديد
    $stmt = $pdo->prepare("UPDATE tasks SET assigned_to = :assigned_to WHERE id = :task_id");
    $stmt->execute([
        ':assigned_to' => $new_user_id,
        ':task_id' => $task_id
    ]);

    // تسجيل الحركة
    log_activity($pdo, $user_id, 'تحويل مهمة', "تم تحويل المهمة $task_id إلى المستخدم $new_user_id.");

    $_SESSION['success_message'] = "تم تحويل المهمة بنجاح.";
    header("Location: manage_tasks.php");
    exit;
}

// معالجة إضافة التعليقات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $task_id = $_POST['task_id'];
    $comment = trim($_POST['comment']);

    if (!empty($comment)) {
        $stmt = $pdo->prepare("INSERT INTO task_comments (task_id, user_id, comment) VALUES (:task_id, :user_id, :comment)");
        $stmt->execute([
            ':task_id' => $task_id,
            ':user_id' => $user_id,
            ':comment' => $comment
        ]);

        $_SESSION['success_message'] = "تم إضافة التعليق بنجاح.";
    } else {
        $_SESSION['error_message'] = "لا يمكن إضافة تعليق فارغ.";
    }

    header("Location: manage_tasks.php");
    exit;
}

// جلب جميع المستخدمين للأدمن والمديرين لتحويل المهام
$users = [];
if ($user_role == 'admin' || $user_role == 'manager') {
    $stmt = $pdo->query("SELECT id, name FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container mt-5">
    <h3>إدارة المهام</h3>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['success_message']; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <table class="table table-hover">
        <thead>
            <tr>
                <th>عنوان المهمة</th>
                <th>الوصف</th>
                <th>الحالة</th>
                <th>المسؤول</th>
                <th>المدة منذ البداية</th>
                <?php if ($user_role == 'admin' || $user_role == 'manager'): ?>
                    <th>خيارات</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?= htmlspecialchars($task['title']) ?></td>
                    <td><?= htmlspecialchars($task['description']) ?></td>
                    <td><?= htmlspecialchars($task['status']) ?></td>
                    <td><?= htmlspecialchars(getUserNameById($pdo, $task['assigned_to'])) ?></td>
                    <td><?= calculateElapsedTime($task['start_date']) ?></td>
                    <?php if ($user_role == 'admin' || $user_role == 'manager'): ?>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                                <button type="submit" name="close_task" class="btn btn-danger btn-sm">إغلاق</button>
                            </form>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#transferModal<?= $task['id'] ?>">تحويل</button>
                            
                            <!-- Modal تحويل المهمة -->
                            <div class="modal fade" id="transferModal<?= $task['id'] ?>" tabindex="-1" aria-labelledby="transferModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="transferModalLabel">تحويل المهمة</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form method="post">
                                            <div class="modal-body">
                                                <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                                                <div class="form-group">
                                                    <label for="assigned_to">اختر المستخدم</label>
                                                    <select name="assigned_to" id="assigned_to" class="form-control" required>
                                                        <?php foreach ($users as $user): ?>
                                                            <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                <button type="submit" name="transfer_task" class="btn btn-primary">تحويل</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td colspan="6">
                        <h5>التعليقات:</h5>
                        <ul>
                            <?php
                            $stmt = $pdo->prepare("SELECT * FROM task_comments WHERE task_id = :task_id ORDER BY created_at DESC");
                            $stmt->execute([':task_id' => $task['id']]);
                            $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            ?>
                            <?php foreach ($comments as $comment): ?>
                                <li>
                                    <strong><?= htmlspecialchars(getUserNameById($pdo, $comment['user_id'])) ?>:</strong>
                                    <?= htmlspecialchars($comment['comment']) ?>
                                    <small class="text-muted"><?= $comment['created_at'] ?></small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <form method="post">
                            <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                            <div class="form-group">
                                <textarea name="comment" class="form-control" placeholder="إضافة تعليق..." required></textarea>
                            </div>
                            <button type="submit" name="add_comment" class="btn btn-primary btn-sm">إضافة تعليق</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

