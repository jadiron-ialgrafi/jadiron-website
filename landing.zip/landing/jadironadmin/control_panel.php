<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database connection
$config = require 'config.php';
$dsn = 'mysql:host=' . $config['database']['host'] . ';dbname=' . $config['database']['database'] . ';port=' . $config['database']['port'];
$pdo = new PDO($dsn, $config['database']['username'], $config['database']['password']);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Handle adding a new social media platform
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['platform'], $_POST['url'])) {
    $platform = $_POST['platform'];
    $url = $_POST['url'];

    if ($platform === 'other' && !empty($_POST['platform_other'])) {
        $platform = $_POST['platform_other'];
    }

    $stmt = $pdo->prepare("INSERT INTO social_media (platform, url, added_by_admin) VALUES (?, ?, 1)");
    if ($stmt->execute([$platform, $url])) {
        $message = "تمت إضافة المنصة بنجاح!";
    } else {
        $message = "حدث خطأ أثناء إضافة المنصة.";
    }
}

// Fetch existing social media platforms
$stmt = $pdo->query("SELECT * FROM social_media");
$socialMedia = $stmt->fetchAll(PDO::FETCH_ASSOC) ?? []; // Initialize as an empty array if no data is found
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f6f9;
            direction: rtl;
            font-family: 'Tajawal', sans-serif;
        }
        .card-custom {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <h2 class="mb-4 text-center">لوحة التحكم</h2>

    <!-- Display success/error message -->
    <?php if ($message): ?>
        <div class="alert alert-info text-center" role="alert">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Social Media Management Section -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card card-custom">
                <h5>إدارة منصات التواصل الاجتماعي</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label>المنصة</label>
                        <select name="platform" class="form-select mb-2" id="platformSelect">
                            <option value="snapchat">Snapchat</option>
                            <option value="twitter">Twitter</option>
                            <option value="instagram">Instagram</option>
                            <option value="facebook">Facebook</option>
                            <option value="linkedin">LinkedIn</option>
                            <option value="other">أخرى</option>
                        </select>
                        <input type="text" name="platform_other" placeholder="أضف منصة جديدة" class="form-control mb-2 d-none" id="platformOther">
                    </div>
                    <div class="mb-3">
                        <label>الرابط</label>
                        <input type="url" name="url" placeholder="https://example.com/username" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">إضافة</button>
                </form>
                <ul class="list-group mt-3">
                    <?php if (!empty($socialMedia)): ?>
                        <?php foreach ($socialMedia as $media): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= htmlspecialchars($media['platform']) ?>
                                <a href="<?= htmlspecialchars($media['url']) ?>" target="_blank"><?= htmlspecialchars($media['url']) ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="list-group-item">لا توجد منصات مضافة</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- General Settings Section -->
        <div class="col-md-6">
            <div class="card card-custom">
                <h5>الإعدادات العامة</h5>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="logoInput" class="form-label">تغيير الشعار</label>
                        <input type="file" class="form-control" id="logoInput" name="logo">
                    </div>
                    <div class="mb-3">
                        <label for="primaryColor" class="form-label">اللون الأساسي</label>
                        <input type="color" class="form-control form-control-color" id="primaryColor" name="primary_color">
                    </div>
                    <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Backup and Security Sections -->
    <div class="row">
        <div class="col-md-6">
            <div class="card card-custom">
                <h5>إدارة النسخ الاحتياطي</h5>
                <button class="btn btn-secondary mb-2">إنشاء نسخة احتياطية</button>
                <button class="btn btn-warning">استعادة نسخة احتياطية</button>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-custom">
                <h5>إعدادات الأمان</h5>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" id="2fa">
                    <label class="form-check-label" for="2fa">تفعيل التحقق بخطوتين</label>
                </div>
                <button class="btn btn-primary">حفظ التغييرات</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Show the "Other" input field when "Other" is selected in the dropdown
    document.querySelector('#platformSelect').addEventListener('change', function() {
        const otherField = document.getElementById('platformOther');
        if (this.value === 'other') {
            otherField.classList.remove('d-none');
            otherField.required = true;
        } else {
            otherField.classList.add('d-none');
            otherField.required = false;
        }
    });
</script>
</body>
</html>

