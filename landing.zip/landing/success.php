<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تم الإرسال بنجاح</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <img src="/img/success.png" alt="تم الإرسال بنجاح">
        <h2>تم إرسال طلبك بنجاح!</h2>
        <p>سنتواصل معك قريبًا.</p>
        <a href="https://jadiron.sa" class="btn btn-primary">العودة إلى الصفحة الرئيسية</a>
    </div>
</body>
</html>
