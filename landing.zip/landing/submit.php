<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require 'vendor/autoload.php'; // تأكد من وجود هذا الملف

// الاتصال بقاعدة البيانات
$config = require 'jadironadmin/config.php';
$dsn = 'mysql:host=' . $config['database']['host'] . ';dbname=' . $config['database']['database'] . ';port=' . $config['database']['port'];
$pdo = new PDO($dsn, $config['database']['username'], $config['database']['password']);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // البيانات المستلمة من النموذج
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $service_id = $_POST['service'];
    $description = $_POST['description'];
    $contact_method = $_POST['contact_method'];
    $contact_time = $_POST['contact_time'];
    $source = $_GET['source'] ?? 'unknown';

    // ترجمة الخيارات
    $contact_method_translated = ($contact_method == 'email') ? 'البريد الإلكتروني' : 'الجوال';
    $contact_time_translated = ($contact_time == 'morning') ? 'صباحاً' : 'مساءً';

    // الحصول على اسم الخدمة من قاعدة البيانات
    $stmt = $pdo->prepare("SELECT name FROM services WHERE id = ?");
    $stmt->execute([$service_id]);
    $service_name = $stmt->fetchColumn();

    // تخزين الطلب في قاعدة البيانات
    $stmt = $pdo->prepare("INSERT INTO contact_requests (name, email, phone, service_id, description, source, contact_method, contact_time, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')");
    $stmt->execute([$name, $email, $phone, $service_id, $description, $source, $contact_method, $contact_time]);

    // إعداد بيانات البريد الإلكتروني
    $emailData = [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'service' => $service_name,
        'description' => $description,
        'contact_method' => $contact_method_translated,
        'contact_time' => $contact_time_translated
    ];

    // عنوان البريد
    $subject = "=?UTF-8?B?" . base64_encode("طلب تواصل جديد : " . $emailData['name']) . "?=";
    
    // محتوى البريد
    $message = "
        <div style='background-color: #f4f6f9; padding: 20px; border-radius: 10px; font-family: Arial, sans-serif; direction: rtl; text-align: right;'>
            <div style='background: #ffffff; padding: 20px; border: 1px solid #ddd; border-radius: 10px; max-width: 600px; margin: auto;'>
                <div style='text-align: center; margin-bottom: 20px;'>
                    <img src='https://jadiron.sa/landing/img/logo.png' alt='شعار جديرون' style='max-width: 100px;'>
                </div>
                <h2 style='color: #003366; text-align: center; font-size: 24px; margin-bottom: 10px;'>طلب تواصل جديد</h2>
                <hr style='border: none; border-top: 2px solid #003366; margin: 20px 0;'>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>الاسم:</strong> {$emailData['name']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>البريد الإلكتروني:</strong> {$emailData['email']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>رقم الجوال:</strong> {$emailData['phone']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>الخدمة المطلوبة:</strong> {$emailData['service']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>وصف الخدمة:</strong> {$emailData['description']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>طريقة التواصل المفضلة:</strong> {$emailData['contact_method']}</p>
                <p style='font-size: 16px; color: #333; line-height: 1.5;'><strong style='color: #003366;'>الوقت المناسب:</strong> {$emailData['contact_time']}</p>
                <hr style='border: none; border-top: 2px solid #ddd; margin: 20px 0;'>
                <footer style='text-align: center; color: #777; font-size: 14px;'>
                    <p style='margin-bottom: 0;'>هذه الرسالة تم إرسالها تلقائيًا - تواصل جديرون - جميع الحقوق محفوظة © 2024</p>
                </footer>
            </div>
        </div>
    ";

    // إرسال الإيميل
    mail('it@jadiron.com', $subject, $message, [
        "From" => $config['mail']['from_address'],
        "MIME-Version" => "1.0",
        "Content-type" => "text/html; charset=UTF-8"
    ]);

    // توجيه المستخدم إلى الصفحة السابقة مع رسالة نجاح
    header("Location: " . $_SERVER['HTTP_REFERER'] . "?success=1");
    exit;
}
?>

